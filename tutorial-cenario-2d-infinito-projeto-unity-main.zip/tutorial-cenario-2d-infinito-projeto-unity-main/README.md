<!--# tutorial-cenario-2d-infinito-projeto-unity-->
 <h1>TUTORIAL: COMO CRIAR UM CENÁRIO INFINITO NA UNITY (2D)</h1>
Nesse repositório você encontra o projeto (com todos os arquivos) do nosso Tutorial "COMO CRIAR UM CENÁRIO INFINITO NA UNITY (2D) | Tutorial passo a passo", do meu canal no YouTube, Desenvolvendo Jogos.
<br>
Espero que se divirta bastante e aprenda diversas coisas novas com ele :)
<br>
Link do tutorial: https://www.youtube.com/watch?v=H-WSIMyXa58

<a href="https://www.youtube.com/watch?v=H-WSIMyXa58" target="_blank">![Como Criar Cenário Infinito 2D na Unity - Miniatura 01](https://user-images.githubusercontent.com/102618272/162992954-3a07ce21-ae50-485a-91d0-8194bb83de5b.png)</a>
